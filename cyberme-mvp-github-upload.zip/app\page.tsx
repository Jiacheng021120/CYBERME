"use client";

import Link from "next/link";
import { CyberBackdrop } from "@/components/CyberBackdrop";

export default function WelcomePage() {
  return (
    <main className="cyber-screen welcome-screen">
      <CyberBackdrop />
      <section className="phone-frame welcome-content">
        <p className="eyebrow">PERSONA SNAPSHOT / CYBER AVATAR</p>
        <h1 className="brand-title">CYBERME</h1>
        <p className="brand-subtitle">你的赛博分身，在你的城市中替你生活</p>

        <div className="avatar-stage" aria-hidden="true">
          <div className="halo" />
          <div className="pixel-avatar">
            <span className="pixel-head" />
            <span className="pixel-body" />
            <span className="pixel-arm left" />
            <span className="pixel-arm right" />
            <span className="pixel-leg left" />
            <span className="pixel-leg right" />
          </div>
          <div className="scanline" />
        </div>

        <Link className="primary-button" href="/questionnaire">
          开启定制
        </Link>
      </section>
    </main>
  );
}
