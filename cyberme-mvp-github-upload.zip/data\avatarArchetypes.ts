export type AvatarArchetype = {
  id: number;
  key: string;
  name: string;
  description: string;
  maleAsset: string;
  femaleAsset: string;
  neutralAsset?: string;
  matchTags: string[];
  matchRules: string[];
};

const fileName = (gender: "male" | "female", id: number, key: string) =>
  `/cyberme-avatars/${gender}_${String(id).padStart(2, "0")}_${key}.png`;

const archetype = (
  id: number,
  key: string,
  name: string,
  description: string,
  matchTags: string[],
  matchRules: string[]
): AvatarArchetype => ({
  id,
  key,
  name,
  description,
  maleAsset: fileName("male", id, key),
  femaleAsset: fileName("female", id, key),
  matchTags,
  matchRules
});

export const avatarArchetypes: AvatarArchetype[] = [
  archetype(1, "quiet_observer", "安静观察者", "适合内向、安静、喜欢独处、咖啡店、书店、细节观察。", ["introverted", "quiet", "alone", "cafe", "bookstore", "detail_observation"], ["social_energy:introverted", "stress_response:alone"]),
  archetype(2, "night_wanderer", "夜色漫游者", "适合喜欢夜晚、霓虹、高楼、神秘感、深夜城市。", ["night", "night_view", "neon_street", "mysterious"], ["preferred_time:night"]),
  archetype(3, "cafe_thinker", "咖啡馆思想家", "适合理性、喜欢思考、咖啡店、书店、图书馆。", ["rational", "cafe", "bookstore", "reading", "library"], ["decision_style:rational"]),
  archetype(4, "gentle_recorder", "温柔记录者", "适合情绪细腻、喜欢日记、治愈、记录生活。", ["warm", "writing", "record_emotion", "healing"], ["exploration_goal:record_emotion", "voice:warm"]),
  archetype(5, "hidden_alley_explorer", "隐藏小巷探索者", "适合喜欢小巷、市集、隐藏地点、非热门路线。", ["hidden_places", "alley", "local_market", "explore_unknown"], ["exploration_style:hidden_gem_explorer", "exploration_goal:explore_unknown"]),
  archetype(6, "city_safety_seeker", "城市安全感寻找者", "适合喜欢稳定、安全、熟悉路线、低风险探索。", ["safe_routine", "slow", "stable"], ["exploration_style:safe_routine", "life_pace:slow"]),
  archetype(7, "slow_life_healer", "慢生活治愈者", "适合慢节奏、公园、河边、自然、治愈风。", ["slow", "park", "riverside", "nature", "healing"], ["life_pace:slow"]),
  archetype(8, "midnight_poet", "深夜诗人", "适合诗意、感性、深夜、幻想、神秘表达。", ["night", "poetic", "writing", "mysterious"], ["preferred_time:night", "voice:poetic"]),
  archetype(9, "planned_explorer", "计划型探索家", "适合计划清楚、路线明确、结构化、效率。", ["structured", "planning", "route", "efficient"], ["planning_style:structured"]),
  archetype(10, "spontaneous_drifter", "随性漂流者", "适合随性、随机、看心情、不喜欢固定计划。", ["spontaneous", "random", "flexible"], ["planning_style:spontaneous", "life_pace:random"]),
  archetype(11, "city_player", "城市玩家", "适合把城市当游戏地图、任务感、探索任务、像素游戏感。", ["game_character", "games", "task", "pixel"], ["avatar_relationship:game_character"]),
  archetype(12, "food_hunter", "美食猎人", "适合美食、餐厅、咖啡店、夜市、市集。", ["food", "restaurant", "cafe", "local_market"], ["exploration_goal:discover_food"]),
  archetype(13, "exhibition_walker", "展览漫步者", "适合艺术、展览、博物馆、文化空间。", ["art_exhibition", "museum", "exhibition", "cultural_space"], ["exploration_style:cultural_explorer"]),
  archetype(14, "music_inspirer", "音乐灵感者", "适合音乐、演出、唱片店、街头声音。", ["music", "events", "street_sound"], ["preference_tags:music"]),
  archetype(15, "cinematic_life_artist", "电影感生活家", "适合电影、剧集、画面感、故事感。", ["movies", "cinematic", "story"], ["preference_tags:movies"]),
  archetype(16, "tech_futurist", "科技未来主义者", "适合 AI、科技、未来感、现代建筑、数码。", ["technology_ai", "digital_products", "cool_future"], ["preference_tags:technology_ai"]),
  archetype(17, "street_style_walker", "潮流街区行者", "适合穿搭、潮流、商圈、街头文化。", ["fashion", "shopping_district", "street_style"], ["preference_tags:fashion"]),
  archetype(18, "travel_dreamer", "旅行幻想家", "适合旅行、陌生感、自由、城市漫游。", ["travel", "live_freely", "explore_unknown"], ["exploration_goal:explore_unknown"]),
  archetype(19, "social_energy_collector", "社交能量收集者", "适合外向、人群、活动、热闹街区。", ["extroverted", "communication", "events", "crowd"], ["social_energy:extroverted"]),
  archetype(20, "close_circle_companion", "熟人圈陪伴者", "适合稳定朋友关系、轻社交、熟人陪伴。", ["balanced", "friend", "close_circle"], ["avatar_relationship:friend"]),
  archetype(21, "online_persona_projector", "线上人格投影者", "适合线上表达更自由、数字身份、网络分身。", ["online", "digital_identity", "technology_ai"], ["social_mode:online"]),
  archetype(22, "emotional_harbor", "情绪避风港", "适合压力时独处、安静恢复、低刺激、安慰感。", ["alone", "warm", "calm", "emotion_recorder"], ["stress_response:alone"]),
  archetype(23, "stress_releaser", "压力释放者", "适合娱乐、购物、吃饭、转移压力、轻松搞笑。", ["distraction", "food", "shopping_district", "humorous"], ["stress_response:distraction"]),
  archetype(24, "outdoor_rebooter", "户外重启者", "适合压力时出门走走、公园、河边、开阔空间。", ["outdoor_reset", "park", "riverside", "nature"], ["stress_response:outdoor_reset"]),
  archetype(25, "rational_route_planner", "理性路线师", "适合逻辑、效率、清晰路线、实际结果。", ["logic", "rational", "structured", "practical_problem_solving"], ["decision_style:rational"]),
  archetype(26, "intuitive_traveler", "直觉旅人", "适合直觉、感觉、心情、光线、天气。", ["emotional", "spontaneous", "depends_on_mood"], ["decision_style:emotional"]),
  archetype(27, "balanced_liver", "平衡型生活者", "适合理性和感性平衡、稳定但不死板。", ["balanced", "flexible", "lifestyle_discovery"], ["decision_style:balanced"]),
  archetype(28, "creative_dream_maker", "创意造梦者", "适合想象力、奇幻、故事世界、创意。", ["imagination", "creative", "story", "fantasy"], ["strengths:imagination"]),
  archetype(29, "detail_catcher", "细节捕捉者", "适合观察细节、记录颜色、气味、声音、小事。", ["detail_observation", "photography", "writing"], ["strengths:detail_observation"]),
  archetype(30, "aesthetic_curator", "审美策展人", "适合审美、搭配、视觉、拍照点、展览。", ["aesthetic", "fashion", "photography", "art_exhibition"], ["strengths:aesthetic"]),
  archetype(31, "comforting_friend", "安慰型朋友", "适合安慰别人、情绪价值、温柔朋友感。", ["empathy", "warm", "friend"], ["strengths:empathy", "voice:warm"]),
  archetype(32, "organized_captain", "组织型队长", "适合组织计划、安排路线、行动力。", ["planning", "structured", "organization"], ["strengths:planning", "planning_style:structured"]),
  archetype(33, "learning_explorer", "学习型探索者", "适合学习新东西、书店、讲座、博物馆、历史街区。", ["learning", "reading", "bookstore", "museum", "historic_block"], ["strengths:learning"]),
  archetype(34, "practical_problem_solver", "现实问题解决者", "适合解决实际问题、实用地点、生活效率。", ["practical_problem_solving", "employee", "efficient"], ["strengths:practical_problem_solving"]),
  archetype(35, "celebrity_inspired_avatar", "明星灵感型分身", "适合有喜欢的明星、偶像、角色或公众人物。", ["celebrity", "appearance_style", "speaking_style", "talent"], ["celebrity_influence:name"]),
  archetype(36, "growth_protagonist", "成长型主角", "适合努力、成长、升级感、主角感。", ["growth", "learning", "protagonist"], ["celebrity_traits:growth"]),
  archetype(37, "mysterious_distance_character", "神秘距离感角色", "适合神秘感、冷感、距离感、少说话。", ["mystery", "mysterious", "direct", "night"], ["celebrity_traits:mystery", "voice:direct"]),
  archetype(38, "friendly_life_character", "亲和生活型角色", "适合真实、自然、亲近、生活化。", ["friendly", "living_block", "warm"], ["celebrity_traits:friendly"]),
  archetype(39, "freedom_escaper", "自由逃离者", "适合自由、逃离日常、去平时不会去的地方。", ["live_freely", "travel", "explore_unknown"], ["exploration_goal:live_freely"]),
  archetype(40, "city_memory_keeper", "城市记忆保管员", "适合晚间日志、长期记忆、城市日记、记录感。", ["record_emotion", "city_diary", "writing", "night"], ["exploration_goal:record_emotion", "avatar_relationship:emotion_recorder"])
];
