CYBERME avatar assets live here.

Expected filenames:

- male_01_quiet_observer.png
- male_02_night_wanderer.png
- ...
- male_40_city_memory_keeper.png
- female_01_quiet_observer.png
- female_02_night_wanderer.png
- ...
- female_40_city_memory_keeper.png

TODO: Add neutral avatar assets later. Until then, non-binary or undisclosed gender uses the male asset path as the neutral fallback in code.

The current app intentionally shows "头像资源待上传" if a PNG is missing. Do not replace that fallback with a robot.
