export type Option = {
  label: string;
  value: string;
  text: string;
};

export type Question = {
  id: string;
  question: string;
  type: "single" | "multiple" | "text";
  options?: Option[];
  placeholder?: string;
};

export const genderOptions: Option[] = [
  { label: "A", value: "female", text: "女" },
  { label: "B", value: "male", text: "男" },
  { label: "C", value: "non_binary_or_other", text: "非二元 / 其他" },
  { label: "D", value: "prefer_not_to_say", text: "不愿透露" }
];

export const ageRangeOptions: Option[] = [
  { label: "A", value: "under_18", text: "18 岁以下" },
  { label: "B", value: "18_24", text: "18-24 岁" },
  { label: "C", value: "25_34", text: "25-34 岁" },
  { label: "D", value: "35_44", text: "35-44 岁" },
  { label: "E", value: "45_plus", text: "45 岁及以上" },
  { label: "F", value: "prefer_not_to_say", text: "不愿透露" }
];

export const occupationOptions: Option[] = [
  { label: "A", value: "student", text: "学生" },
  { label: "B", value: "employee", text: "上班族" },
  { label: "C", value: "freelancer", text: "自由职业者" },
  { label: "D", value: "entrepreneur", text: "创业者" },
  { label: "E", value: "no_fixed_job", text: "暂时没有固定职业" },
  { label: "F", value: "other", text: "其他，请输入" },
  { label: "G", value: "prefer_not_to_say", text: "不愿透露" }
];

export const mbtiOptions: Option[] = [
  "INTJ",
  "INTP",
  "ENTJ",
  "ENTP",
  "INFJ",
  "INFP",
  "ENFJ",
  "ENFP",
  "ISTJ",
  "ISFJ",
  "ESTJ",
  "ESFJ",
  "ISTP",
  "ISFP",
  "ESTP",
  "ESFP"
].map((type, index) => ({
  label: String.fromCharCode(65 + index),
  value: type,
  text: type
})).concat([
  { label: "Q", value: "unknown", text: "我不知道" },
  { label: "R", value: "prefer_not_to_say", text: "不愿透露" }
]);

export const relationshipOptions: Option[] = [
  { label: "A", value: "another_self", text: "另一个我" },
  { label: "B", value: "friend", text: "我的朋友" },
  { label: "C", value: "city_proxy", text: "我的城市替身" },
  { label: "D", value: "emotion_recorder", text: "我的情绪记录者" },
  { label: "E", value: "game_character", text: "我的探索游戏角色" }
];

const options = (texts: string[]) =>
  texts.map((text, index) => ({
    label: String.fromCharCode(65 + index),
    value: String.fromCharCode(65 + index),
    text
  }));

export const questions: Question[] = [
  {
    id: "q1",
    question: "当你有一整天自由时间时，你更想怎么过？",
    type: "single",
    options: options(["一个人安静待着，恢复能量", "和一两个熟悉的人轻松见面", "去热闹的地方，感受人群和气氛", "临时出门，看看会遇到什么新东西"])
  },
  {
    id: "q2",
    question: "你更像哪一种人？",
    type: "single",
    options: options(["做事前喜欢计划清楚", "有大概方向就可以开始", "主要看当下心情", "喜欢别人给我一些建议后再决定"])
  },
  {
    id: "q3",
    question: "做决定时，你通常更依靠什么？",
    type: "single",
    options: options(["逻辑、数据和现实结果", "感受、直觉和个人喜好", "别人的反馈和关系影响", "我会在理性和感觉之间平衡"])
  },
  {
    id: "q4",
    question: "当你压力很大时，你更可能怎么做？",
    type: "single",
    options: options(["独处，慢慢消化", "找朋友说出来", "通过吃饭、购物、娱乐转移注意力", "出门走走，让环境改变心情"])
  },
  {
    id: "q5",
    question: "你的生活节奏更接近哪一种？",
    type: "single",
    options: options(["慢节奏，喜欢稳定", "有规律，但偶尔想变化", "快节奏，喜欢效率", "随机变化，喜欢新鲜感"])
  },
  {
    id: "q6",
    question: "到一个陌生城市时，你第一时间会想去哪里？",
    type: "single",
    options: options(["安静的咖啡店或书店", "热门商圈和地标", "博物馆、展览或历史街区", "小巷、市集、当地人才知道的地方"])
  },
  {
    id: "q7",
    question: "哪种城市空间最吸引你？",
    type: "single",
    options: options(["夜景、高楼、霓虹灯", "公园、河边、自然风景", "商场、餐厅、生活街区", "老建筑、艺术区、文化空间"])
  },
  {
    id: "q8",
    question: "一天中哪个时间最像你的气质？",
    type: "single",
    options: options(["清晨，安静清醒", "下午，稳定日常", "傍晚，温柔放松", "深夜，神秘自由"])
  },
  {
    id: "q9",
    question: "你希望你的赛博分身主要替你体验什么？",
    type: "single",
    options: options(["替我发现城市里的好吃好玩", "替我过一种更自由的生活", "替我记录情绪和生活感受", "替我探索我平时不会去的地方"])
  },
  {
    id: "q10",
    question: "你和城市的关系更像哪一种？",
    type: "single",
    options: options(["我需要城市给我安全感", "我想在城市里找到自己的节奏", "我喜欢城市带来的机会和刺激", "我把城市当成一个可以探索的游戏地图"])
  },
  {
    id: "q11",
    question: "你的兴趣爱好有哪些？可多选。",
    type: "multiple",
    options: options(["美食", "音乐", "电影 / 剧集", "游戏", "运动 / 健身", "摄影", "旅行", "阅读", "时尚 / 穿搭", "艺术 / 展览", "科技 / AI", "其他，请输入"])
  },
  {
    id: "q12",
    question: "你觉得自己比较擅长什么？可多选。",
    type: "multiple",
    options: options(["观察细节", "逻辑分析", "审美和搭配", "写作和表达", "安慰别人", "组织计划", "学习新东西", "社交沟通", "创意想象", "解决实际问题", "其他，请输入"])
  },
  {
    id: "q13",
    question: "你平时更喜欢哪类内容？",
    type: "single",
    options: options(["轻松搞笑", "情绪治愈", "科技未来感", "生活方式和探店", "明星娱乐", "深度知识", "悬疑、奇幻或世界观设定"])
  },
  {
    id: "q14",
    question: "你有喜欢的明星、偶像、角色或公众人物吗？",
    type: "text",
    placeholder: "可以输入名字，也可以写“没有”。"
  },
  {
    id: "q15",
    question: "如果有，你喜欢 TA 的哪种特质？",
    type: "multiple",
    options: options(["外形风格", "说话方式", "才华能力", "努力和成长感", "神秘感或距离感", "真实、有亲和力", "没有特别喜欢的人"])
  },
  {
    id: "q16",
    question: "你更喜欢哪种社交状态？",
    type: "single",
    options: options(["少量深度关系", "稳定朋友圈", "热闹、多认识新人", "线上互动比线下更舒服"])
  },
  {
    id: "q17",
    question: "你更愿意把钱花在哪里？",
    type: "multiple",
    options: options(["好吃的", "好看的衣服或配饰", "旅行和体验", "数码产品", "演唱会、展览、活动", "我更喜欢存钱", "看心情"])
  },
  {
    id: "q18",
    question: "你希望你的赛博分身外观更接近哪种风格？",
    type: "single",
    options: options(["暗黑赛博风", "可爱像素风", "冷酷未来风", "街头潮流风", "温柔治愈风", "神秘夜行者风"])
  },
  {
    id: "q19",
    question: "你希望你的赛博分身说话是什么感觉？",
    type: "single",
    options: options(["温柔陪伴型", "冷静理性型", "幽默吐槽型", "神秘诗意型", "活泼朋友型", "简短直接型"])
  },
  {
    id: "q20",
    question: "用一句话描述你理想中的一天。",
    type: "text",
    placeholder: "睡到自然醒，喝咖啡，去一个没去过的地方，然后晚上写下今天的心情。"
  }
];
