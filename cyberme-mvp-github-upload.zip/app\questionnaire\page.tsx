"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  ageRangeOptions,
  genderOptions,
  mbtiOptions,
  occupationOptions,
  questions,
  relationshipOptions,
  type Option,
  type Question
} from "@/data/questionnaire";
import {
  BasicInfo,
  STORAGE_KEYS,
  buildPersonaSnapshot,
  buildStoredAnswers,
  generateUserId,
  saveToLocalStorage
} from "@/lib/cyberme";
import { CyberBackdrop } from "@/components/CyberBackdrop";

const defaultBasicInfo: BasicInfo = {
  nickname: "",
  gender: "prefer_not_to_say",
  age_range: "prefer_not_to_say",
  occupation: "prefer_not_to_say",
  occupation_other: null,
  mbti: "unknown",
  base_city: "",
  avatar_relationship: "another_self"
};

export default function PersonaQuestionnairePage() {
  const router = useRouter();
  const [step, setStep] = useState<"basic" | "questions">("basic");
  const [basicInfo, setBasicInfo] = useState<BasicInfo>(defaultBasicInfo);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string | string[]>>({});

  const progress = step === "basic" ? 0 : ((currentQuestion + 1) / questions.length) * 100;
  const question = questions[currentQuestion];
  const canGoNext = isAnswered(question, answers[question.id]);

  const storedAnswers = useMemo(() => buildStoredAnswers(answers), [answers]);

  function updateBasicInfo<K extends keyof BasicInfo>(key: K, value: BasicInfo[K]) {
    setBasicInfo((current) => ({ ...current, [key]: value }));
  }

  function updateAnswer(value: string) {
    if (question.type === "multiple") {
      const current = Array.isArray(answers[question.id]) ? (answers[question.id] as string[]) : [];
      const next = current.includes(value) ? current.filter((item) => item !== value) : [...current, value];
      setAnswers((currentAnswers) => ({ ...currentAnswers, [question.id]: next }));
      return;
    }

    setAnswers((currentAnswers) => ({ ...currentAnswers, [question.id]: value }));
  }

  function goNext() {
    if (!canGoNext) return;
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion((index) => index + 1);
      return;
    }

    const userId = generateUserId();
    const questionnaireAnswers = {
      user_id: userId,
      basic_info: basicInfo,
      answers: storedAnswers,
      created_at: new Date().toISOString()
    };
    const personaSnapshot = buildPersonaSnapshot(basicInfo, storedAnswers);

    saveToLocalStorage(STORAGE_KEYS.questionnaireAnswers, questionnaireAnswers);
    saveToLocalStorage(STORAGE_KEYS.personaSnapshot, personaSnapshot);
    router.push("/avatar-result");
  }

  return (
    <main className="cyber-screen app-screen">
      <CyberBackdrop />
      <section className="phone-frame questionnaire-frame">
        <div className="topbar">
          <div>
            <p className="eyebrow">CYBERME SETUP</p>
            <h1 className="page-title">定制你的 CyberMe</h1>
          </div>
          <span className="progress-label">{step === "basic" ? "基础信息" : `${currentQuestion + 1} / ${questions.length}`}</span>
        </div>
        <p className="page-subtitle">回答这些问题，让你的赛博分身学会你的性格、兴趣和城市偏好。</p>
        <div className="progress-track">
          <span style={{ width: step === "basic" ? "10%" : `${progress}%` }} />
        </div>

        {step === "basic" ? (
          <BasicInfoForm
            basicInfo={basicInfo}
            setBasicInfo={updateBasicInfo}
            onStart={() => setStep("questions")}
          />
        ) : (
          <div className="question-card">
            <p className="question-index">QUESTION {currentQuestion + 1}</p>
            <h2>{question.question}</h2>

            {question.type === "text" ? (
              <textarea
                className="text-input textarea"
                placeholder={question.placeholder}
                value={(answers[question.id] as string) ?? ""}
                onChange={(event) => updateAnswer(event.target.value)}
              />
            ) : (
              <OptionList
                question={question}
                value={answers[question.id]}
                onChange={updateAnswer}
              />
            )}

            <div className="action-row">
              <button
                className="secondary-button"
                type="button"
                onClick={() => {
                  if (currentQuestion === 0) setStep("basic");
                  else setCurrentQuestion((index) => index - 1);
                }}
              >
                上一题
              </button>
              <button className="primary-button compact" type="button" disabled={!canGoNext} onClick={goNext}>
                {currentQuestion === questions.length - 1 ? "生成我的赛博分身" : "下一题"}
              </button>
            </div>
          </div>
        )}
      </section>
    </main>
  );
}

function BasicInfoForm({
  basicInfo,
  setBasicInfo,
  onStart
}: {
  basicInfo: BasicInfo;
  setBasicInfo: <K extends keyof BasicInfo>(key: K, value: BasicInfo[K]) => void;
  onStart: () => void;
}) {
  return (
    <div className="question-card">
      <h2>先认识一下你</h2>
      <p className="muted">这些信息会帮助 CyberMe 更准确地生成你的赛博分身。你可以选择跳过部分问题。</p>

      <label className="field-label">
        你的称呼 / 昵称
        <input
          className="text-input"
          placeholder="例如：小林、Alex、Momo"
          value={basicInfo.nickname}
          onChange={(event) => setBasicInfo("nickname", event.target.value)}
        />
      </label>

      <ChoiceGroup title="你的性别" options={genderOptions} value={basicInfo.gender} onChange={(value) => setBasicInfo("gender", value)} />
      <ChoiceGroup title="你的年龄段" options={ageRangeOptions} value={basicInfo.age_range} onChange={(value) => setBasicInfo("age_range", value)} />
      <ChoiceGroup title="你的职业 / 身份" options={occupationOptions} value={basicInfo.occupation} onChange={(value) => setBasicInfo("occupation", value)} />

      {basicInfo.occupation === "other" ? (
        <label className="field-label">
          其他职业 / 身份
          <input
            className="text-input"
            placeholder="请输入你的身份描述"
            value={basicInfo.occupation_other ?? ""}
            onChange={(event) => setBasicInfo("occupation_other", event.target.value)}
          />
        </label>
      ) : null}

      <ChoiceGroup title="你的 MBTI 是什么？" options={mbtiOptions} value={basicInfo.mbti} onChange={(value) => setBasicInfo("mbti", value)} dense />

      <label className="field-label">
        你目前主要生活或想让 CyberMe 探索的城市是哪里？
        <input
          className="text-input"
          placeholder="例如：上海、墨尔本、东京、深圳"
          value={basicInfo.base_city}
          onChange={(event) => setBasicInfo("base_city", event.target.value)}
        />
      </label>

      <ChoiceGroup title="你希望 CyberMe 更像哪一种关系？" options={relationshipOptions} value={basicInfo.avatar_relationship} onChange={(value) => setBasicInfo("avatar_relationship", value)} />

      <button className="primary-button full" type="button" onClick={onStart}>
        开始定制
      </button>
    </div>
  );
}

function ChoiceGroup({
  title,
  options,
  value,
  onChange,
  dense = false
}: {
  title: string;
  options: Option[];
  value: string;
  onChange: (value: string) => void;
  dense?: boolean;
}) {
  return (
    <fieldset className={dense ? "choice-group dense" : "choice-group"}>
      <legend>{title}</legend>
      <div className="option-grid">
        {options.map((option) => (
          <button
            className={value === option.value ? "option-pill active" : "option-pill"}
            key={option.value}
            type="button"
            onClick={() => onChange(option.value)}
          >
            <span>{option.label}</span>
            {option.text}
          </button>
        ))}
      </div>
    </fieldset>
  );
}

function OptionList({
  question,
  value,
  onChange
}: {
  question: Question;
  value: string | string[] | undefined;
  onChange: (value: string) => void;
}) {
  return (
    <div className="answer-list">
      {question.options?.map((option) => {
        const selected = Array.isArray(value) ? value.includes(option.value) : value === option.value;
        return (
          <button
            className={selected ? "answer-option active" : "answer-option"}
            key={option.value}
            type="button"
            onClick={() => onChange(option.value)}
          >
            <span className="answer-letter">{option.label}</span>
            <span>{option.text}</span>
          </button>
        );
      })}
    </div>
  );
}

function isAnswered(question: Question, value: string | string[] | undefined) {
  if (question.type === "multiple") return Array.isArray(value) && value.length > 0;
  return typeof value === "string" && value.trim().length > 0;
}
