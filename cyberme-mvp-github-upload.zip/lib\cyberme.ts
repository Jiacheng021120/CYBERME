import { avatarArchetypes, type AvatarArchetype } from "@/data/avatarArchetypes";
import { questions } from "@/data/questionnaire";

export const STORAGE_KEYS = {
  userId: "cyberme_user_id",
  questionnaireAnswers: "cyberme_questionnaire_answers",
  personaSnapshot: "cyberme_persona_snapshot",
  cyberAvatar: "cyberme_cyber_avatar"
} as const;

export type BasicInfo = {
  nickname: string;
  gender: string;
  age_range: string;
  occupation: string;
  occupation_other: string | null;
  mbti: string;
  base_city: string;
  avatar_relationship: string;
};

export type StoredAnswer = {
  question_id: string;
  question: string;
  answer: string | string[];
  answer_text: string | string[];
};

export type QuestionnaireAnswers = {
  user_id: string;
  basic_info: BasicInfo;
  answers: StoredAnswer[];
  created_at: string;
};

export type PersonaSnapshot = {
  user_id: string;
  persona_id: string;
  basic_identity: {
    nickname: string;
    gender: string;
    age_range: string;
    occupation: string;
    mbti: string;
    base_city: string;
    avatar_relationship: string;
  };
  core_traits: {
    social_energy: "introverted" | "balanced" | "extroverted";
    planning_style: "structured" | "flexible" | "spontaneous";
    decision_style: "rational" | "emotional" | "balanced";
    stress_response: "alone" | "social_support" | "distraction" | "outdoor_reset";
    exploration_style: "safe_routine" | "lifestyle_discovery" | "cultural_explorer" | "hidden_gem_explorer";
    life_pace: "slow" | "balanced" | "fast" | "random";
  };
  tone_style: {
    voice: "warm" | "rational" | "humorous" | "poetic" | "energetic" | "direct";
    language: "simple Chinese";
    emotional_temperature: "calm" | "warm" | "playful" | "mysterious";
  };
  preference_tags: string[];
  strengths: string[];
  city_bias: {
    base_city: string;
    preferred_places: string[];
    preferred_time: "morning" | "afternoon" | "evening" | "night";
    spending_preference: string[];
    exploration_goal: "discover_food" | "live_freely" | "record_emotion" | "explore_unknown";
  };
  celebrity_influence: {
    name: string | "none";
    liked_traits: string[];
  };
  avatar_prompt: string;
  avatar_asset: null;
  profilePrompt: string;
  content_preference?: string;
  visual_style?: CyberAvatar["visual_style"];
  ideal_day_seed?: string;
};

export type CyberAvatar = {
  avatar_id: string;
  persona_id: string;
  user_id: string;
  display_name: string;
  status_line: string;
  archetype_id: number;
  archetype_key: string;
  archetype_name: string;
  gender_version: "male" | "female" | "neutral";
  avatar_image: string;
  visual_style: "dark_cyber" | "cute_pixel" | "cool_future" | "street_style" | "healing" | "night_walker";
  avatar_prompt: string;
  persona_summary: string;
  city_summary: string;
  tone_summary: string;
  created_at: string;
};

const labelMaps: Record<string, Record<string, string>> = {
  gender: {
    female: "女",
    male: "男",
    non_binary_or_other: "非二元 / 其他",
    prefer_not_to_say: "不愿透露"
  },
  age_range: {
    under_18: "18 岁以下",
    "18_24": "18-24 岁",
    "25_34": "25-34 岁",
    "35_44": "35-44 岁",
    "45_plus": "45 岁及以上",
    prefer_not_to_say: "不愿透露"
  },
  occupation: {
    student: "学生",
    employee: "上班族",
    freelancer: "自由职业者",
    entrepreneur: "创业者",
    no_fixed_job: "暂时没有固定职业",
    other: "其他",
    prefer_not_to_say: "不愿透露"
  },
  avatar_relationship: {
    another_self: "另一个我",
    friend: "朋友陪伴",
    city_proxy: "城市替身",
    emotion_recorder: "情绪记录者",
    game_character: "探索游戏角色"
  },
  social_energy: {
    introverted: "偏内向",
    balanced: "平衡",
    extroverted: "偏外向"
  },
  planning_style: {
    structured: "计划清晰",
    flexible: "灵活推进",
    spontaneous: "随性即兴"
  },
  decision_style: {
    rational: "理性现实",
    emotional: "感受直觉",
    balanced: "理性与感觉平衡"
  },
  stress_response: {
    alone: "独处消化",
    social_support: "寻求支持",
    distraction: "转移注意",
    outdoor_reset: "外出重启"
  },
  exploration_style: {
    safe_routine: "安全日常型",
    lifestyle_discovery: "生活方式发现型",
    cultural_explorer: "文化探索型",
    hidden_gem_explorer: "隐藏地点探索型"
  },
  life_pace: {
    slow: "慢节奏",
    balanced: "规律且有变化",
    fast: "快节奏",
    random: "随机新鲜"
  },
  voice: {
    warm: "温柔陪伴型",
    rational: "冷静理性型",
    humorous: "幽默吐槽型",
    poetic: "神秘诗意型",
    energetic: "活泼朋友型",
    direct: "简短直接型"
  },
  emotional_temperature: {
    calm: "平静",
    warm: "温暖",
    playful: "轻快",
    mysterious: "神秘"
  },
  preferred_time: {
    morning: "清晨",
    afternoon: "下午",
    evening: "傍晚",
    night: "深夜"
  },
  exploration_goal: {
    discover_food: "发现城市里的好吃好玩",
    live_freely: "替用户过一种更自由的生活",
    record_emotion: "记录情绪和生活感受",
    explore_unknown: "探索平时不会去的地方"
  },
  visual_style: {
    dark_cyber: "暗黑赛博风",
    cute_pixel: "可爱像素风",
    cool_future: "冷酷未来风",
    street_style: "街头潮流风",
    healing: "温柔治愈风",
    night_walker: "神秘夜行者风"
  }
};

const tagMap: Record<string, string> = {
  美食: "food",
  音乐: "music",
  "电影 / 剧集": "movies",
  游戏: "games",
  "运动 / 健身": "fitness",
  摄影: "photography",
  旅行: "travel",
  阅读: "reading",
  "时尚 / 穿搭": "fashion",
  "艺术 / 展览": "art_exhibition",
  "科技 / AI": "technology_ai",
  "其他，请输入": "other_interest"
};

const strengthMap: Record<string, string> = {
  观察细节: "detail_observation",
  逻辑分析: "logic",
  审美和搭配: "aesthetic",
  写作和表达: "writing",
  安慰别人: "empathy",
  组织计划: "planning",
  学习新东西: "learning",
  社交沟通: "communication",
  创意想象: "imagination",
  解决实际问题: "practical_problem_solving",
  "其他，请输入": "other_strength"
};

export function generateUserId() {
  if (typeof window === "undefined") {
    return `user_${Date.now()}`;
  }

  const existingId = window.localStorage.getItem(STORAGE_KEYS.userId);
  if (existingId) return existingId;

  const id = `user_${Date.now()}_${Math.random().toString(16).slice(2, 8)}`;
  window.localStorage.setItem(STORAGE_KEYS.userId, id);
  return id;
}

export function saveToLocalStorage<T>(key: string, value: T) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error(`Failed to save ${key}`, error);
  }
}

export function loadFromLocalStorage<T>(key: string): T | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch (error) {
    console.error(`Failed to load ${key}`, error);
    return null;
  }
}

export async function copyToClipboard(text: string) {
  if (typeof navigator !== "undefined" && navigator.clipboard) {
    await navigator.clipboard.writeText(text);
    return;
  }

  const textarea = document.createElement("textarea");
  textarea.value = text;
  textarea.setAttribute("readonly", "true");
  textarea.style.position = "fixed";
  textarea.style.opacity = "0";
  document.body.appendChild(textarea);
  textarea.select();
  document.execCommand("copy");
  document.body.removeChild(textarea);
}

export function buildStoredAnswers(rawAnswers: Record<string, string | string[]>) {
  return questions.map((question) => {
    const value = rawAnswers[question.id] ?? (question.type === "multiple" ? [] : "");
    const answerText = Array.isArray(value)
      ? value.map((item) => question.options?.find((option) => option.value === item)?.text ?? item)
      : question.options?.find((option) => option.value === value)?.text ?? value;

    return {
      question_id: question.id,
      question: question.question,
      answer: value,
      answer_text: answerText
    };
  });
}

export function buildPersonaSnapshot(basicInfo: BasicInfo, answers: StoredAnswer[]): PersonaSnapshot {
  const userId = generateUserId();
  const answerMap = Object.fromEntries(answers.map((answer) => [answer.question_id, answer]));
  const getAnswer = (id: string) => answerMap[id]?.answer;
  const getText = (id: string) => answerMap[id]?.answer_text;

  const q1 = getAnswer("q1");
  const q16 = getAnswer("q16");
  const socialEnergy =
    q1 === "C" || q16 === "C"
      ? "extroverted"
      : q1 === "A" || q16 === "A" || q16 === "D"
        ? "introverted"
        : "balanced";

  const planningStyle = getAnswer("q2") === "A" ? "structured" : getAnswer("q2") === "C" ? "spontaneous" : "flexible";
  const decisionStyle = getAnswer("q3") === "A" ? "rational" : getAnswer("q3") === "B" || getAnswer("q3") === "C" ? "emotional" : "balanced";
  const stressResponseMap = { A: "alone", B: "social_support", C: "distraction", D: "outdoor_reset" } as const;
  const lifePaceMap = { A: "slow", B: "balanced", C: "fast", D: "random" } as const;
  const preferredTimeMap = { A: "morning", B: "afternoon", C: "evening", D: "night" } as const;
  const explorationGoalMap = { A: "discover_food", B: "live_freely", C: "record_emotion", D: "explore_unknown" } as const;

  const q6 = getAnswer("q6");
  const q7 = getAnswer("q7");
  const q10 = getAnswer("q10");
  const explorationStyle =
    q6 === "D" || q10 === "D"
      ? "hidden_gem_explorer"
      : q6 === "C" || q7 === "D"
        ? "cultural_explorer"
        : q6 === "B" || q7 === "C" || q10 === "C"
          ? "lifestyle_discovery"
          : "safe_routine";

  const preferredPlaces = unique([
    ...(q6 === "A" ? ["cafe", "bookstore"] : []),
    ...(q6 === "B" ? ["landmark", "shopping_district"] : []),
    ...(q6 === "C" ? ["museum", "exhibition", "historic_block"] : []),
    ...(q6 === "D" ? ["alley", "local_market", "hidden_places"] : []),
    ...(q7 === "A" ? ["night_view", "neon_street", "high_rise"] : []),
    ...(q7 === "B" ? ["park", "riverside", "nature"] : []),
    ...(q7 === "C" ? ["mall", "restaurant", "living_block"] : []),
    ...(q7 === "D" ? ["old_building", "art_district", "cultural_space"] : [])
  ]);

  const preferenceTags = textArray(getText("q11")).map((item) => tagMap[item] ?? item);
  const strengths = textArray(getText("q12")).map((item) => strengthMap[item] ?? item);
  const spendingPreference = textArray(getText("q17")).map((item) => spendingTag(item));
  const likedTraits = textArray(getText("q15")).map((item) => celebrityTrait(item));

  const visual = visualFromAnswer(String(getAnswer("q18") ?? "A"));
  const tone = toneFromAnswer(String(getAnswer("q19") ?? "A"));
  const avatarPrompt = buildAvatarPrompt(visual, basicInfo.base_city, preferredPlaces, preferenceTags);

  const snapshotWithoutPrompt = {
    user_id: userId,
    persona_id: `persona_${Date.now()}`,
    basic_identity: {
      nickname: basicInfo.nickname,
      gender: basicInfo.gender,
      age_range: basicInfo.age_range,
      occupation: basicInfo.occupation === "other" && basicInfo.occupation_other ? basicInfo.occupation_other : basicInfo.occupation,
      mbti: basicInfo.mbti,
      base_city: basicInfo.base_city,
      avatar_relationship: basicInfo.avatar_relationship
    },
    core_traits: {
      social_energy: socialEnergy,
      planning_style: planningStyle,
      decision_style: decisionStyle,
      stress_response: stressResponseMap[String(getAnswer("q4")) as keyof typeof stressResponseMap] ?? "outdoor_reset",
      exploration_style: explorationStyle,
      life_pace: lifePaceMap[String(getAnswer("q5")) as keyof typeof lifePaceMap] ?? "balanced"
    },
    tone_style: tone,
    preference_tags: preferenceTags,
    strengths,
    city_bias: {
      base_city: basicInfo.base_city,
      preferred_places: preferredPlaces.length ? preferredPlaces : ["cafe", "night_view", "local_market"],
      preferred_time: preferredTimeMap[String(getAnswer("q8")) as keyof typeof preferredTimeMap] ?? "evening",
      spending_preference: spendingPreference,
      exploration_goal: explorationGoalMap[String(getAnswer("q9")) as keyof typeof explorationGoalMap] ?? "explore_unknown"
    },
    celebrity_influence: {
      name: normalizeCelebrityName(String(getText("q14") ?? "")),
      liked_traits: likedTraits
    },
    avatar_prompt: avatarPrompt,
    avatar_asset: null,
    profilePrompt: "",
    content_preference: String(getText("q13") ?? ""),
    visual_style: visual,
    ideal_day_seed: String(getText("q20") ?? "")
  } satisfies PersonaSnapshot;

  return {
    ...snapshotWithoutPrompt,
    profilePrompt: buildProfilePrompt(basicInfo, answers, snapshotWithoutPrompt)
  };
}

export function buildProfilePrompt(basicInfo: BasicInfo, answers: StoredAnswer[], personaSnapshot: PersonaSnapshot) {
  const identity = personaSnapshot.basic_identity;
  const traits = personaSnapshot.core_traits;
  const city = personaSnapshot.city_bias;
  const celebrity = personaSnapshot.celebrity_influence;

  return `这是 CYBERME 用户的赛博分身画像。

基础信息：
用户称呼是${identity.nickname || "未填写"}。
用户年龄段是${display("age_range", identity.age_range)}。
用户职业 / 身份是${display("occupation", identity.occupation)}。
用户自填 MBTI 是${identity.mbti || "未填写"}。
用户希望 CyberMe 探索的城市是${identity.base_city || "未填写"}。
用户希望 CyberMe 更像${display("avatar_relationship", identity.avatar_relationship)}。

注意：以上信息只来自用户主动填写，不代表正式心理诊断，也不能用于刻板化判断。

用户核心性格：
用户的社交能量倾向是${display("social_energy", traits.social_energy)}，做事方式偏${display("planning_style", traits.planning_style)}，决策时更接近${display("decision_style", traits.decision_style)}。压力下更可能通过${display("stress_response", traits.stress_response)}来恢复，生活节奏偏${display("life_pace", traits.life_pace)}。

用户兴趣与特长：
兴趣标签包括：${personaSnapshot.preference_tags.join("、") || "未填写"}。擅长方向包括：${personaSnapshot.strengths.join("、") || "未填写"}。平时喜欢的内容类型是${personaSnapshot.content_preference || "未填写"}。

用户城市探索偏好：
默认探索城市是${city.base_city || "未填写"}。喜欢的城市空间包括：${city.preferred_places.join("、")}。更适合在${display("preferred_time", city.preferred_time)}展开探索，主要目标是${display("exploration_goal", city.exploration_goal)}。

用户情绪与生活节奏：
CyberMe 的行动路线需要有情绪逻辑，既符合用户${display("life_pace", traits.life_pace)}的节奏，也要回应用户理想中的一天：${personaSnapshot.ideal_day_seed || "未填写"}。

用户审美与分身风格：
分身视觉风格是${display("visual_style", personaSnapshot.visual_style ?? "dark_cyber")}。视觉生成提示词：${personaSnapshot.avatar_prompt}

用户喜欢的明星/人物影响：
喜欢的人物是${celebrity.name === "none" ? "无或未填写" : celebrity.name}。用户喜欢的特质包括：${celebrity.liked_traits.join("、") || "未填写"}。

后续每日探索生成规则：
1. 分身每天的行动要符合用户的性格、兴趣和基础生活背景。
2. 地点选择要优先匹配用户喜欢的城市空间和 base_city。
3. 如果用户是学生，可以适当加入校园、图书馆、学习、年轻生活方式等元素。
4. 如果用户是上班族，可以适当加入通勤、下班、咖啡、夜晚放松、周末探索等元素。
5. 如果用户不愿透露职业，不要主动猜测。
6. MBTI 只能作为用户自我描述标签，不能当成正式心理诊断。
7. 路线不要过于随机，要有情绪逻辑。
8. 晚间日志要使用用户偏好的语气。
9. 如果用户偏内向，探索可以更安静、更细腻。
10. 如果用户偏外向，探索可以更热闹、更社交。
11. 如果用户喜欢文化内容，多安排展览、书店、历史街区。
12. 如果用户喜欢夜晚和赛博感，多安排夜景、霓虹、城市灯光。
13. 如果用户喜欢美食，多加入餐厅、咖啡店、市集。
14. 每天生成内容时，要保留一点未知感，让用户觉得分身真的在城市中生活。`;
}

export function buildCyberAvatar(personaSnapshot: PersonaSnapshot): CyberAvatar {
  const nickname = personaSnapshot.basic_identity.nickname?.trim();
  const city = personaSnapshot.city_bias.base_city || "城市";
  const relationship = personaSnapshot.basic_identity.avatar_relationship;
  const displayName = nickname ? `${nickname} 的 CyberMe` : "CyberMe-01";
  const selectedArchetype = selectAvatarArchetype(personaSnapshot);
  const { genderVersion, avatarImage } = selectAvatarAsset(personaSnapshot, selectedArchetype);
  const relationshipLine: Record<string, string> = {
    another_self: "像另一个你一样，在城市里慢慢生活。",
    friend: `今天也在${city}寻找适合你的咖啡、灯光和故事。`,
    city_proxy: `正在${city}的夜色里替你收集城市碎片。`,
    emotion_recorder: `正在${city}记录那些微小但真实的情绪波纹。`,
    game_character: `探索任务已启动，${city}地图正在发光。`
  };

  return {
    avatar_id: `avatar_${Date.now()}`,
    persona_id: personaSnapshot.persona_id,
    user_id: personaSnapshot.user_id,
    display_name: displayName,
    status_line: relationshipLine[relationship] ?? relationshipLine.city_proxy,
    archetype_id: selectedArchetype.id,
    archetype_key: selectedArchetype.key,
    archetype_name: selectedArchetype.name,
    gender_version: genderVersion,
    avatar_image: avatarImage,
    visual_style: personaSnapshot.visual_style ?? "dark_cyber",
    avatar_prompt: personaSnapshot.avatar_prompt,
    persona_summary: `${selectedArchetype.name}会带着${display("social_energy", personaSnapshot.core_traits.social_energy)}的能量，在城市里以${display("life_pace", personaSnapshot.core_traits.life_pace)}的节奏行动。TA 做决定时更接近${display("decision_style", personaSnapshot.core_traits.decision_style)}，适合有情绪线索的探索。`,
    city_summary: `默认探索城市是${city}。TA 更容易被${personaSnapshot.city_bias.preferred_places.join("、")}吸引。`,
    tone_summary: `CyberMe 会用${display("voice", personaSnapshot.tone_style.voice)}的方式，以简洁中文和你对话。`,
    created_at: new Date().toISOString()
  };
}

export function selectAvatarArchetype(personaSnapshot: PersonaSnapshot): AvatarArchetype {
  const scores = avatarArchetypes.map((archetype) => ({
    archetype,
    score: 0,
    goalScore: 0,
    timeScore: 0
  }));

  const addScore = (key: string, points: number, source: "goal" | "time" | "general" = "general") => {
    const item = scores.find((score) => score.archetype.key === key);
    if (!item) return;
    item.score += points;
    if (source === "goal") item.goalScore += points;
    if (source === "time") item.timeScore += points;
  };

  const identity = personaSnapshot.basic_identity;
  const traits = personaSnapshot.core_traits;
  const city = personaSnapshot.city_bias;
  const tags = new Set(personaSnapshot.preference_tags);
  const strengths = new Set(personaSnapshot.strengths);
  const places = new Set(city.preferred_places);
  const likedTraits = new Set(personaSnapshot.celebrity_influence.liked_traits);

  if (personaSnapshot.celebrity_influence.name !== "none") addScore("celebrity_inspired_avatar", 1000, "goal");

  if (city.exploration_goal === "live_freely") addScore("freedom_escaper", 120, "goal");
  if (city.exploration_goal === "record_emotion") {
    addScore("city_memory_keeper", 115, "goal");
    addScore("gentle_recorder", 104, "goal");
  }
  if (city.exploration_goal === "discover_food") addScore("food_hunter", 120, "goal");
  if (city.exploration_goal === "explore_unknown") {
    addScore("hidden_alley_explorer", 112, "goal");
    addScore("travel_dreamer", 96, "goal");
  }

  if (city.preferred_time === "night") {
    addScore("night_wanderer", 80, "time");
    addScore("midnight_poet", 68, "time");
    addScore("mysterious_distance_character", 56, "time");
  }

  if (traits.exploration_style === "cultural_explorer") {
    addScore("exhibition_walker", 70);
    addScore("learning_explorer", 58);
    addScore("aesthetic_curator", 48);
  }
  if (traits.exploration_style === "hidden_gem_explorer") addScore("hidden_alley_explorer", 72);
  if (traits.exploration_style === "safe_routine") addScore("city_safety_seeker", 58);
  if (traits.exploration_style === "lifestyle_discovery") addScore("balanced_liver", 42);

  if (traits.social_energy === "extroverted") addScore("social_energy_collector", 66);
  if (traits.social_energy === "introverted") {
    addScore("quiet_observer", 64);
    addScore("emotional_harbor", 50);
    addScore("cafe_thinker", 42);
  }

  if (traits.planning_style === "structured") {
    addScore("planned_explorer", 62);
    addScore("organized_captain", 50);
    addScore("rational_route_planner", 44);
  }
  if (traits.planning_style === "spontaneous") {
    addScore("spontaneous_drifter", 62);
    addScore("city_player", 46);
    addScore("intuitive_traveler", 40);
  }

  if (traits.decision_style === "rational") addScore("rational_route_planner", 42);
  if (traits.decision_style === "emotional") addScore("intuitive_traveler", 42);
  if (traits.decision_style === "balanced") addScore("balanced_liver", 38);

  if (traits.stress_response === "alone") addScore("emotional_harbor", 42);
  if (traits.stress_response === "distraction") addScore("stress_releaser", 42);
  if (traits.stress_response === "outdoor_reset") addScore("outdoor_rebooter", 42);
  if (traits.stress_response === "social_support") addScore("comforting_friend", 34);

  if (identity.avatar_relationship === "game_character") addScore("city_player", 44);
  if (identity.avatar_relationship === "emotion_recorder") addScore("city_memory_keeper", 44);
  if (identity.avatar_relationship === "friend") addScore("close_circle_companion", 36);

  if (tags.has("food")) addScore("food_hunter", 38);
  if (tags.has("music")) addScore("music_inspirer", 38);
  if (tags.has("movies")) addScore("cinematic_life_artist", 38);
  if (tags.has("games")) addScore("city_player", 38);
  if (tags.has("photography")) {
    addScore("detail_catcher", 30);
    addScore("aesthetic_curator", 26);
  }
  if (tags.has("travel")) addScore("travel_dreamer", 38);
  if (tags.has("reading")) {
    addScore("cafe_thinker", 30);
    addScore("learning_explorer", 28);
  }
  if (tags.has("fashion")) {
    addScore("street_style_walker", 34);
    addScore("aesthetic_curator", 28);
  }
  if (tags.has("art_exhibition")) addScore("exhibition_walker", 38);
  if (tags.has("technology_ai")) addScore("tech_futurist", 38);

  if (strengths.has("logic")) addScore("rational_route_planner", 34);
  if (strengths.has("aesthetic")) addScore("aesthetic_curator", 34);
  if (strengths.has("writing")) {
    addScore("gentle_recorder", 28);
    addScore("midnight_poet", 26);
  }
  if (strengths.has("communication")) addScore("social_energy_collector", 32);
  if (strengths.has("planning")) addScore("organized_captain", 34);
  if (strengths.has("imagination")) addScore("creative_dream_maker", 34);
  if (strengths.has("practical_problem_solving")) addScore("practical_problem_solver", 34);
  if (strengths.has("detail_observation")) addScore("detail_catcher", 34);
  if (strengths.has("empathy")) addScore("comforting_friend", 34);
  if (strengths.has("learning")) addScore("learning_explorer", 34);

  if (places.has("night_view") || places.has("neon_street") || places.has("high_rise")) addScore("night_wanderer", 24, "time");
  if (places.has("cafe") || places.has("bookstore")) addScore("cafe_thinker", 22);
  if (places.has("museum") || places.has("exhibition") || places.has("cultural_space")) addScore("exhibition_walker", 22);
  if (places.has("local_market") || places.has("alley") || places.has("hidden_places")) addScore("hidden_alley_explorer", 22);
  if (places.has("park") || places.has("riverside") || places.has("nature")) addScore("slow_life_healer", 22);

  if (likedTraits.has("growth")) addScore("growth_protagonist", 30);
  if (likedTraits.has("mystery")) addScore("mysterious_distance_character", 30);
  if (likedTraits.has("friendly")) addScore("friendly_life_character", 30);
  if (likedTraits.has("appearance_style")) addScore("aesthetic_curator", 18);
  if (likedTraits.has("speaking_style")) addScore("celebrity_inspired_avatar", 16);
  if (likedTraits.has("talent")) addScore("celebrity_inspired_avatar", 16);

  if (personaSnapshot.tone_style.voice === "poetic") addScore("midnight_poet", 24);
  if (personaSnapshot.tone_style.voice === "warm") addScore("comforting_friend", 20);
  if (personaSnapshot.tone_style.voice === "humorous") addScore("stress_releaser", 20);
  if (personaSnapshot.tone_style.voice === "direct") addScore("mysterious_distance_character", 16);

  scores.sort((left, right) => {
    if (right.score !== left.score) return right.score - left.score;
    if (right.goalScore !== left.goalScore) return right.goalScore - left.goalScore;
    if (right.timeScore !== left.timeScore) return right.timeScore - left.timeScore;
    return left.archetype.id - right.archetype.id;
  });

  return scores[0]?.archetype ?? avatarArchetypes[0];
}

function selectAvatarAsset(personaSnapshot: PersonaSnapshot, archetype: AvatarArchetype) {
  const gender = personaSnapshot.basic_identity.gender;
  if (gender === "female") {
    return { genderVersion: "female" as const, avatarImage: archetype.femaleAsset };
  }

  // TODO: Add neutral avatar assets. For now, non-binary or undisclosed gender uses the male asset path as the neutral fallback.
  if (gender !== "male") {
    return { genderVersion: "neutral" as const, avatarImage: archetype.neutralAsset ?? archetype.maleAsset };
  }

  return { genderVersion: "male" as const, avatarImage: archetype.maleAsset };
}

export function display(group: string, value: string) {
  return labelMaps[group]?.[value] ?? value;
}

function textArray(value: string | string[] | undefined) {
  if (!value) return [];
  return Array.isArray(value) ? value : [value];
}

function unique(items: string[]) {
  return Array.from(new Set(items.filter(Boolean)));
}

function spendingTag(text: string) {
  const map: Record<string, string> = {
    好吃的: "food",
    好看的衣服或配饰: "fashion",
    旅行和体验: "travel",
    数码产品: "digital_products",
    "演唱会、展览、活动": "events",
    我更喜欢存钱: "saving",
    看心情: "depends_on_mood"
  };
  return map[text] ?? text;
}

function celebrityTrait(text: string) {
  const map: Record<string, string> = {
    外形风格: "appearance_style",
    说话方式: "speaking_style",
    才华能力: "talent",
    努力和成长感: "growth",
    神秘感或距离感: "mystery",
    "真实、有亲和力": "friendly",
    没有特别喜欢的人: "none"
  };
  return map[text] ?? text;
}

function normalizeCelebrityName(name: string): string | "none" {
  const normalized = name.trim();
  if (!normalized || ["没有", "无", "none", "不填"].includes(normalized.toLowerCase())) {
    return "none";
  }
  return normalized;
}

function visualFromAnswer(answer: string): CyberAvatar["visual_style"] {
  const map: Record<string, CyberAvatar["visual_style"]> = {
    A: "dark_cyber",
    B: "cute_pixel",
    C: "cool_future",
    D: "street_style",
    E: "healing",
    F: "night_walker"
  };
  return map[answer] ?? "dark_cyber";
}

function toneFromAnswer(answer: string): PersonaSnapshot["tone_style"] {
  const map: Record<string, PersonaSnapshot["tone_style"]> = {
    A: { voice: "warm", language: "simple Chinese", emotional_temperature: "warm" },
    B: { voice: "rational", language: "simple Chinese", emotional_temperature: "calm" },
    C: { voice: "humorous", language: "simple Chinese", emotional_temperature: "playful" },
    D: { voice: "poetic", language: "simple Chinese", emotional_temperature: "mysterious" },
    E: { voice: "energetic", language: "simple Chinese", emotional_temperature: "playful" },
    F: { voice: "direct", language: "simple Chinese", emotional_temperature: "calm" }
  };
  return map[answer] ?? map.A;
}

function buildAvatarPrompt(visualStyle: CyberAvatar["visual_style"], city: string, places: string[], tags: string[]) {
  const styleText = display("visual_style", visualStyle);
  return `A ${styleText} pixel cyber avatar standing in a neon night city inspired by ${city || "the user's city"}, with ${places.slice(0, 3).join(", ") || "urban lights"} atmosphere and hints of ${tags.slice(0, 3).join(", ") || "personal interests"}, mobile app character card style.`;
}
